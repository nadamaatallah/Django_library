from django import forms
from django.contrib.auth.models import User
from django.core.exceptions import ValidationError

class ClientUserForm(forms.ModelForm):
    class Meta:
        model = User  # Assurez-vous que le modèle Client existe, ou utilisez User si nécessaire
        fields = ['first_name', 'last_name', 'username', 'password', 'email']

    def clean_username_or_email(self):
        data = self.cleaned_data['username_or_email']
        # Vérifie si l'utilisateur a saisi un email ou un nom d'utilisateur
        if '@' in data:
            # Si c'est un email, on cherche l'utilisateur par email
            try:
                user = User.objects.get(email=data)
                return user.username  # Retourne le nom d'utilisateur associé à cet email
            except User.DoesNotExist:
                raise ValidationError("Aucun utilisateur n'existe avec cet email.")
        else:
            # Si ce n'est pas un email, c'est un nom d'utilisateur
            return data
