from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from .models import Client, Book, Transaction
from .forms import ClientForm, BookForm, TransactionForm
from django.http import HttpResponse,JsonResponse
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login

def admin_login(request):
    if request.method == "POST":
        # Check if the form has been submitted
        username = request.POST['username']
        password = request.POST['password']
       
        # Authenticate the user (admin credentials)
        user = authenticate(request, username=username, password=password)
       
        if user is not None and user.is_superuser:
            # If admin, log the user in and redirect to admin home
            login(request, user)
            return redirect('home')  # Replace with your admin homepage URL
        else:
            # If authentication fails or not superuser, show error
            return HttpResponse("Invalid credentials or you are not a superuser.", status=403)
   
    return render(request, 'admin/admin_login.html')


# HOME PAGE
def home(request):
    return render(request, 'admin/home.html')

# CLIENT CRUD
def client_list(request):
    clients = Client.objects.all()
    return render(request, 'admin/clients/clients.html', {'clients': clients})

def client_create(request):
    if request.method == 'POST':
        form = ClientForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Client created successfully')
            return redirect('client_list')
        
        else:
            messages.error(request, 'Please correct the errors below.')
    else:
        form = ClientForm()
    return render(request, 'admin/clients/add_client.html', {'form': form})

def client_update(request, id):
    client = get_object_or_404(Client, id=id)

    if request.method == 'POST':
        form = ClientForm(request.POST, instance=client)
        if form.is_valid():
            form.save()
            messages.success(request, 'Client updated successfully!')
            return redirect('client_list')  # Redirect to the client list page
    else:
        form = ClientForm(instance=client)

    return render(request, 'admin/clients/update_client.html', {'form': form, 'client': client})

def client_delete(request, id):
    client = get_object_or_404(Client, id=id)
    if request.method == 'POST':
        client.delete()
        messages.success(request, 'Client deleted successfully!')
        return redirect('client_list')  # Redirect to the client list page
    return render(request, 'admin/clients/delete_client.html', {'client': client})

# BOOK CRUD
def book_list(request):
    books = Book.objects.all()
    return render(request, 'admin/books/books.html', {'books': books})

def book_create(request):
    if request.method == 'POST':
        form = BookForm(request.POST,request.FILES)
        if form.is_valid():
            form.save()
            messages.success(request, 'Book added successfully!')
            return redirect('book_list')
        else:
            messages.error(request, 'Error occured while adding book')
    else:
        form = BookForm()
    return render(request, 'admin/books/add_book.html', {'form': form})

def book_update(request, id):
    book = get_object_or_404(Book, id=id)
    if request.method == 'POST':
        form = BookForm(request.POST,request.FILES, instance=book)
        print("POST data:", request.POST)
        print("FILES data:", request.FILES)

        
        if form.is_valid():
            form.save()
            messages.success(request, 'Book updated successfully')
            return redirect('book_list')
        else:
            print("Form errors:", form.errors)
            messages.error(request, 'Erreur lors de la mise à jour.')
    else:
        form = BookForm(instance=book)
    return render(request, 'admin/books/update_book.html', {'form': form, 'book': book})

def book_delete (request, id):
    book = get_object_or_404(Book, id=id)

    if request.method == 'POST':
        book.delete()
        messages.success(request, f'The book  "{book.title}" was successfully deleted')
        return redirect('book_list')  # Redirect to the book list

    return render(request, 'admin/books/delete_book.html', {'book': book})

# TRANSACTION CRUD
def transaction_list(request):
    transactions = Transaction.objects.all()  # Fetch all transactions
    for transaction in transactions:
        print(f"Transaction ID: {transaction.id}")  # Print each transaction's ID to the console
    return render(request, 'admin/transactions/transactions.html', {'transactions': transactions})

def transaction_create(request):
    if request.method == 'POST':
        form = TransactionForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Transaction created successfully')
            return redirect('transaction_list')
        else :
            messages.error(request, 'Error occured while adding transaction')
    else:
        form = TransactionForm()

    # Fetch clients and books for dropdowns
    clients = Client.objects.all()  # Query all clients   ### New
    books = Book.objects.all()  # Query all books         ### New
    

    # Debugging: Check what's being passed
    if not clients or not books:
        return JsonResponse({'clients': list(clients.values()), 'books': list(books.values())}) ### New
    

    return render(request, 'admin/transactions/add_transaction.html', {'form': form,'clients': clients,'books': books}) #### New

def transaction_update(request, id):
    transaction = get_object_or_404(Transaction, id=id)
    if request.method == 'POST':
        form = TransactionForm(request.POST, instance=transaction)
        if form.is_valid():
            form.save()
            messages.success(request, 'Transaction updated successfully')
            return redirect('transaction_list')
    else:
        form = TransactionForm(instance=transaction)
    
        # Fetch clients and books for dropdowns
    clients = Client.objects.all()  # Query all clients   ### New
    books = Book.objects.all() 
    return render(request, 'admin/transactions/update_transaction.html', {'form': form,'clients': clients,'books': books})



def transaction_delete(request, id):
    transaction = get_object_or_404(Transaction, id=id)
    transaction.delete()
    return redirect('transaction_list')  


