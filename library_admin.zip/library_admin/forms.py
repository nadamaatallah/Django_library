from django import forms
from .models import Client, Book, Transaction

class ClientForm(forms.ModelForm):
    class Meta:
        model = Client
        fields = '__all__'

class BookForm(forms.ModelForm):
    class Meta:
        model = Book
        fields = '__all__'  


class TransactionForm(forms.ModelForm):
    class Meta:
        model = Transaction
        fields = '__all__'
