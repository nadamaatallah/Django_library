from django.db import models

# Create your models here.
from django.db import models
from django.contrib.auth.hashers import make_password, check_password


from django.db import models
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager

class ReaderManager(BaseUserManager):
    def create_user(self, email, password=None, **extra_fields):
        if not email:
            raise ValueError('The Email field must be set')
        email = self.normalize_email(email)
        user = self.model(email=email, **extra_fields)
        user.set_password(password)
        user.save(using=self._db)
        return user

    def create_superuser(self, email, password=None, **extra_fields):
        extra_fields.setdefault('is_staff', True)
        extra_fields.setdefault('is_superuser', True)

        # Ensure superuser creation does not require a Client
        extra_fields.setdefault('client', None)

        return self.create_user(email, password, **extra_fields)

class Reader(AbstractBaseUser):
    email = models.EmailField(unique=True)
    first_name = models.CharField(max_length=30)
    last_name = models.CharField(max_length=30)
    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False)
    is_superuser = models.BooleanField(default=False)  # Add this field for superusers

    # Allow superusers to exist without a Client
    client = models.OneToOneField(
        'Client', 
        on_delete=models.CASCADE, 
        related_name='reader',
        null=True,  # Superusers won't need a Client
        blank=True
    )

    objects = ReaderManager()

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['first_name', 'last_name']  # Fields required for creating a user (besides email)

    def __str__(self):
        return self.email

    # Required for Django superusers
    def has_perm(self, perm, obj=None):
        return self.is_superuser

    def has_module_perms(self, app_label):
        return self.is_superuser

class Client(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField(unique=True)  # Ensure uniqueness for authentication
    phone = models.CharField(max_length=15, blank=True, null=True)
    registered_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name



class Book(models.Model):
    title = models.CharField(max_length=200)
    author = models.CharField(max_length=100)
    isbn = models.CharField(max_length=13, unique=True)
    available_copies = models.IntegerField(default=1)
    cover_image = models.ImageField(upload_to='media/covers/', null=True, blank=True)

    def __str__(self):
        return self.title

class Transaction(models.Model):
    client = models.ForeignKey(Client, on_delete=models.CASCADE)
    book = models.ForeignKey(Book, on_delete=models.CASCADE)
    borrowed_at = models.DateTimeField(auto_now_add=True)
    returned_at = models.DateTimeField(null=True, blank=True)

    def is_returned(self):
        return self.returned_at is not None
