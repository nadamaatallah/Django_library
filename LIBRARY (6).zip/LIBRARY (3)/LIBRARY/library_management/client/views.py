from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import login
from .models import Client
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import authenticate
from django.contrib.auth import login as auth_login
from django.contrib.auth import logout as auth_logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .forms import ClientUserForm
from django import forms
from django.contrib.auth.models import User
from django.core.exceptions import ValidationError

def client_list(request):
    clients = Client.objects.all()
    return render(request, 'client/client_list.html', {'clients': clients})

def signup(request):
    if request.method == 'POST':
        form = ClientUserForm(request.POST)
        if form.is_valid():
            # Créer l'utilisateur avec les données du formulaire
            first_name = form.cleaned_data['first_name']
            last_name = form.cleaned_data['last_name']
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            email = form.cleaned_data['email']
            
            # Création de l'utilisateur
            user = User.objects.create_user(username=username, first_name=first_name, last_name=last_name, email=email, password=password)
            messages.success(request, f"Compte créé avec succès, bienvenue {user.username} !")
            
            # Connexion automatique de l'utilisateur après inscription
            auth_login(request, user) 
            return redirect('client:welcome')  # Rediriger vers la page de bienvenue ou page d'accueil
        else:
            messages.error(request, "Une erreur est survenue. Veuillez vérifier les informations.")
    else:
        form = ClientUserForm()  # Créer un formulaire vide si c'est un GET

    return render(request, 'client/signup.html', {'form': form})





def client_login(request):
    if request.method == 'POST':
        username_or_email = request.POST.get('username_or_email')
        password = request.POST.get('password')

        # Essayer de récupérer l'utilisateur par email ou nom d'utilisateur
        if '@' in username_or_email:
            try:
                user = User.objects.get(email=username_or_email)
            except User.DoesNotExist:
                user = None
        else:
            user = User.objects.filter(username=username_or_email).first()

        if user and user.check_password(password):
            auth_login(request, user)
            messages.success(request, f"Bienvenue, {user.first_name or user.username}!")
            return redirect('client:welcome')
        else:
            messages.error(request, "Identifiants invalides.")
    
    return render(request, 'client/login.html')


def logout(request):
    auth_logout(request)
    return redirect('/')  # Rediriger après la déconnexion

def home(request):
    return render(request, 'client/home.html')

@login_required
def welcome(request):
    # Récupère le nom de l'utilisateur connecté
    user_name = request.user.first_name or request.user.username  # Utilise le prénom ou le nom d'utilisateur
    return render(request, 'client/welcome.html', {'user_name': user_name})


def client_view(request):
    return render(request, 'clientclick.html') 