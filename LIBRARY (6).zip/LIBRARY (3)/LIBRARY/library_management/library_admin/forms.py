from django import forms
from .models import Client, Book, Transaction

class ClientForm(forms.ModelForm):
    class Meta:
        model = Client
        fields = '__all__'

class BookForm(forms.ModelForm):
    class Meta:
        model = Book
        fields = '__all__'

class TransactionForm(forms.ModelForm):
    class Meta:
        model = Transaction
        fields = '__all__'

from django import forms
from .models import Reader

from django import forms
from .models import Reader, Client

from django import forms
from .models import Reader, Client

from django import forms
from .models import Reader, Client

class ReaderSignUpForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput)

    class Meta:
        model = Reader
        fields = ['email', 'first_name', 'last_name', 'password']

    def save(self, commit=True):
        user = super().save(commit=False)
        user.set_password(self.cleaned_data['password'])

        # Create a Client object and link it to the Reader
        client = Client.objects.create()  # Or populate fields of Client as needed
        user.client = client  # Associate the new Reader with the Client

        if commit:
            user.save()
        return user

from django import forms

class ReaderSignInForm(forms.Form):
    email = forms.EmailField()
    password = forms.CharField(widget=forms.PasswordInput)
