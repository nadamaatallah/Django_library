from django import forms
from .models import Client, Book, Transaction

class ClientForm(forms.ModelForm):
    class Meta:
        model = Client
        fields = '__all__'

class BookForm(forms.ModelForm):
    class Meta:
        model = Book
        fields = '__all__'

class TransactionForm(forms.ModelForm):
    class Meta:
        model = Transaction
        fields = '__all__'

from django import forms
from .models import Client, Reader

# SignUp Form
class ReaderSignUpForm(forms.ModelForm):
    class Meta:
        model = Client
        fields = ['name', 'email', 'phone']  # client fields

    password = forms.CharField(widget=forms.PasswordInput)

    def save(self, commit=True):
        client = super().save(commit=False)
        if commit:
            client.save()

        reader = Reader.objects.create(client=client)
        reader.set_password(self.cleaned_data['password'])
        reader.save()
        return client

# SignIn Form
class ReaderSignInForm(forms.Form):
    username = forms.EmailField()
    password = forms.CharField(widget=forms.PasswordInput)
