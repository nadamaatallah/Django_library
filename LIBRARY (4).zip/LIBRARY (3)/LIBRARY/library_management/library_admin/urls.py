from django.urls import path
from . import views

urlpatterns = [
    #admin
    path('', views.base_page, name='base_page'),
    path('admin/login/', views.admin_login, name='admin_login'),
    path('reader/sign-up/', views.reader_sign_up, name='reader_sign_up'),
    path('reader/sign-in/', views.reader_sign_in, name='reader_sign_in'),
    path('reader/home/', views.home_reader, name='home_reader'),
    #path('reader/logout/', views.reader_sign_out, name='reader_sign_out'),

    # Home
    path('admin/home', views.home, name='home'),
    
    # Clients
    path('clients/', views.client_list, name='client_list'),
    path('clients/new/', views.client_create, name='client_create'),
    path('clients/edit/<int:id>/', views.client_update, name='client_update'),
    path('clients/delete/<int:id>/', views.client_delete, name='client_delete'),

    # Books
    path('books/', views.book_list, name='book_list'),
    path('books/new/', views.book_create, name='book_create'),
    path('books/edit/<int:id>/', views.book_update, name='book_update'),
    path('books/delete/<int:id>/', views.delete_book, name='book_delete'),

    # Transactions
    path('transactions/', views.transaction_list, name='transaction_list'),
    path('transactions/new/', views.transaction_create, name='transaction_create'),
    path('transactions/edit/<int:id>/', views.transaction_update, name='transaction_update'),
    path('transactions/delete/<int:id>/', views.transaction_delete, name='transaction_delete'),
]
