from django.apps import AppConfig


class LibraryAdminConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "library_admin"
