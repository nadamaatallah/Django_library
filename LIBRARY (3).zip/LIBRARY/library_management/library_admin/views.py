from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from .models import Client, Book, Transaction
from .forms import ClientForm, BookForm, TransactionForm

# views.py
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.http import HttpResponse
from django.contrib.auth.models import User

def base_page(request):
    return render(request, 'base.html')

def admin_login(request):
    if request.method == "POST":
        # Check if the form has been submitted
        username = request.POST['username']
        password = request.POST['password']
        
        # Authenticate the user (admin credentials)
        user = authenticate(request, username=username, password=password)
        
        if user is not None and user.is_superuser:
            # If admin, log the user in and redirect to admin home
            login(request, user)
            return redirect('home')  # Replace with your admin homepage URL
        else:
            # If authentication fails or not superuser, show error
            return HttpResponse("Invalid credentials or you are not a superuser.", status=403)
    
    return render(request, 'admin/admin_login.html')


# HOME PAGE
def home(request):
    return render(request, 'admin/home.html')

# CLIENT CRUD
def client_list(request):
    clients = Client.objects.all()
    return render(request, 'admin/clients/clients.html', {'clients': clients})

def client_create(request):
    if request.method == 'POST':
        form = ClientForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Client created successfully')
            return redirect('client_list')
        else:
            messages.error(request, 'Please correct the errors below.')
    else:
        form = ClientForm()
    return render(request, 'admin/clients/add_client.html', {'form': form})

# View for updating an existing client
def client_update(request, id):
    client = get_object_or_404(Client, id=id)

    if request.method == 'POST':
        form = ClientForm(request.POST, instance=client)
        if form.is_valid():
            form.save()
            messages.success(request, 'Client updated successfully!')
            return redirect('client_list')  # Redirect to the client list page
    else:
        form = ClientForm(instance=client)

    return render(request, 'admin/clients/update_client.html', {'form': form, 'client': client})

def client_delete(request, id):
    client = get_object_or_404(Client, id=id)
    if request.method == 'POST':
        client.delete()
        messages.success(request, 'Client deleted successfully!')
        return redirect('client_list')  # Redirect to the client list page
    return render(request, 'admin/clients/delete_client.html', {'client': client})

# Book CRUD
def book_list(request):
    books = Book.objects.all()
    return render(request, 'admin/books/books.html', {'books': books})

def book_create(request):
    if request.method == 'POST':
        form = BookForm(request.POST, request.FILES)  # 🛑 Add request.FILES to handle image uploads
        if form.is_valid():
            form.save()
            messages.success(request, 'Livre ajouté avec succès!')
            return redirect('book_list')
        else:
            messages.error(request, 'Erreur lors de l\'ajout du livre.')
    else:
        form = BookForm()
    return render(request, 'admin/books/add_book.html', {'form': form})

def book_update(request, id):
    book = get_object_or_404(Book, id=id)

    if request.method == 'POST':
        form = BookForm(request.POST, request.FILES, instance=book)  # 🛑 Include request.FILES
        print("POST data:", request.POST)
        print("FILES data:", request.FILES)

        if form.is_valid():
            form.save()
            messages.success(request, 'Livre mis à jour avec succès!')
            return redirect('book_list')
        else:
            print("Form errors:", form.errors)
            messages.error(request, 'Erreur lors de la mise à jour.')

    else:
        form = BookForm(instance=book)

    return render(request, 'admin/books/update_book.html', {'form': form, 'book': book})



def delete_book(request, id):
    book = get_object_or_404(Book, id=id)

    if request.method == 'POST':
        book.delete()
        messages.success(request, f'Le livre "{book.title}" a été supprimé avec succès!')
        return redirect('book_list')  # Redirect to the book list

    return render(request, 'admin/books/delete_book.html', {'book': book})


# TRANSACTION CRUD
def transaction_list(request):
    transactions = Transaction.objects.all()
    return render(request, 'admin/transactions/transactions.html', {'transactions': transactions})

def transaction_create(request):
    if request.method == 'POST':
        form = TransactionForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Transaction created successfully')
            return redirect('transaction_list')
    else:
        form = TransactionForm()
    return render(request, 'admin/transactions/add_transaction.html', {'form': form})

def transaction_update(request, id):
    transaction = get_object_or_404(Transaction, id=id)
    if request.method == 'POST':
        form = TransactionForm(request.POST, instance=transaction)
        if form.is_valid():
            form.save()
            messages.success(request, 'Transaction updated successfully')
            return redirect('transaction_list')
    else:
        form = TransactionForm(instance=transaction)
    return render(request, 'admin/transactions/update_transaction.html', {'form': form})

def transaction_delete(request, id):
    transaction = get_object_or_404(Transaction, id=id)
    if request.method == 'POST':
        transaction.delete()
        messages.success(request, 'Transaction deleted successfully')
        return redirect('transaction_list')
    return render(request, 'admin/transactions/delete_transaction.html', {'transaction': transaction})